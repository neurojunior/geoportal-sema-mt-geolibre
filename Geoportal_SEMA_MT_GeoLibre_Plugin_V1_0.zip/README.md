# Geoportal SEMA-MT para GeoLibre Desktop — V1.0

Plugin independente para consultar os serviços oficiais do Geoportal da
SEMA-MT diretamente no GeoLibre Desktop.

## Instalação

1. Abra **Plugins > Gerenciar plugins > Configurações**.
2. Em **Instalar a partir de arquivo**, selecione este ZIP.
3. Ative **Geoportal SEMA-MT** no menu Plugins.
4. Abra o painel pelo menu **Geoportal SEMA-MT** ou pelo botão **MT** no mapa.

## Visualização

- Pesquise e filtre mosaicos e bases publicadas no WMS oficial.
- Use **Adicionar ao mapa** para registrar a camada no painel de camadas do
  GeoLibre.
- A opacidade inicial pode ser definida antes da inclusão; depois, visibilidade,
  ordem e transparência continuam disponíveis no controle de camadas do GeoLibre.

## Download

- Pesquise as camadas vetoriais disponíveis no WFS oficial.
- Formatos: Shapefile compactado e GeoJSON.
- Escopo: camada completa, extensão visível no mapa ou extensão dos objetos
  desenhados no GeoLibre.
- O recorte por extensão utiliza uma caixa envolvente (BBOX), não o recorte
  geométrico exato do polígono.

## Observações

- Mosaicos de satélite e modelos raster são disponibilizados apenas para
  visualização remota por WMS.
- O plugin não executa Python, não abre servidor local e não chama o `main.py`.
- A disponibilidade e o desempenho dependem dos serviços oficiais da SEMA-MT.
- Fonte oficial: Secretaria de Estado de Meio Ambiente de Mato Grosso.

